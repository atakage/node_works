var express = require('express');
var router = express.Router();

router.get('/login', function(req,res){
    res.render('login');
})


router.post('/join', function(req,res){
    let id = req.body.id.replace(/ /g,'')
    let password = req.body.password.replace(/ /g,'')
    let grade = req.body.grade.replace(/ /g,'')

    console.log(id)
    console.log(id.length)

    // server에서 2차 검사
    if(id.length > 8 || id.length < 4){
        res.redirect('/member/login')
    }
    if(password.length < 10 || password.length > 20){
        res.redirect('/member/login')
    }
    if(grade != 'N' || grade != 'P'){
        res.redirect('/member/login')
    }
    
})



module.exports = router;